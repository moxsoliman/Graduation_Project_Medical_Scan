# Disease Prediction Web App

This project combines a HTML/CSS/JS frontend with a Python FastAPI backend
that serves a neural network disease prediction model.

## Structure

- `frontend/` — login, symptom selection, processing, and result pages.
- `backend/` — FastAPI app (`main.py`) and dependencies (`requirements.txt`).
- `model/` — trained Keras model and training data:
  - `disease_prediction_model.keras`
  - `training_data.csv`

## How to Run the Backend

1. Create a virtual environment (optional but recommended):

```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Start the API server:

```bash
uvicorn main:app --reload
```

The API will run by default at: `http://127.0.0.1:8000`.

## How to Use with the Frontend

1. Open `frontend/login_page/index.html` in your browser (or use a simple HTTP server).
2. Log in (no backend auth — just a UI step).
3. Click **Start** to go to symptom selection.
4. Select your symptoms and click **Predict Disease**.
5. The app will:
   - Save selected symptoms in `localStorage`.
   - Go to the processing page, which calls `http://127.0.0.1:8000/predict`.
   - Redirect to the result page and display the predicted disease.

> Make sure the backend is running before using the frontend, so the prediction works correctly.
