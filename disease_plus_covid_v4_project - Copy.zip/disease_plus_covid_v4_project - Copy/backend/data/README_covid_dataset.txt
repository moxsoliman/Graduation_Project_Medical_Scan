COVID merged training dataset (template + synthetic sample)

This CSV is a *synthetic* training dataset generated to match the exact input fields used by the COVID form in your project.
It is useful to test the full pipeline (preprocessing -> training -> saving model -> backend inference),
but it is NOT medical/clinical-grade data.

You can replace it later with a real merged dataset with the same column names.

Columns:
- age (number)
- gender (male/female)
- high_temperature (0/1) + temperature_c (number or empty)
- high_blood_pressure (0/1) + systolic_bp/diastolic_bp (number or empty)
- spo2 (number or empty)
- symptoms_started (categorical: '1 day'..'7 days'/'more than 7 days')
- contact_confirmed (yes/no) + contact_days_ago (same categories + 'not sure')
- travelled_recently (yes/no) + travel_days_ago (same categories + 'not sure')
- 20 symptom checkbox columns (0/1)
- label_current (0/1) target

