from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Optional

import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model  # type: ignore
from sklearn.preprocessing import LabelEncoder, StandardScaler
from covid_model import load_or_create, predict_proba as covid_predict_proba

import os
import sqlite3
import hashlib

# Paths relative to this backend folder
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "..", "model", "disease_prediction_model.keras")
TRAIN_PATH = os.path.join(BASE_DIR, "..", "model", "training_data.csv")
DB_PATH = os.path.join(BASE_DIR, "users.db")

COVID_MODEL_PATH = os.path.join(BASE_DIR, "models", "covid_v2.joblib")

app = FastAPI(
    title="Disease Prediction API",
    description="Backend API that connects the symptom-based frontend with the neural network model and handles user login/register.",
    version="1.1.0",
)

# --- CORS (allow frontend to talk to backend) ---
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # you can restrict this later (e.g. to http://localhost:5500)
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Data models ---
class SymptomsInput(BaseModel):
    symptoms: List[str]

class CovidSymptoms(BaseModel):
    fever: bool = False
    dry_cough: bool = False
    shortness_of_breath: bool = False
    chest_tightness: bool = False
    fatigue: bool = False
    sore_throat: bool = False
    runny_stuffy_nose: bool = False
    sneezing: bool = False
    hoarse_voice: bool = False
    headache: bool = False
    loss_smell: bool = False
    loss_taste: bool = False
    dizziness: bool = False
    body_aches: bool = False
    joint_pain: bool = False
    nausea: bool = False
    vomiting: bool = False
    diarrhea: bool = False
    stomach_pain: bool = False
    chills: bool = False


class CovidAssessInput(BaseModel):
    age: int
    gender: str  # 'male' / 'female'

    has_high_temp: bool = False
    temperature_c: Optional[float] = None

    has_high_bp: bool = False
    systolic_bp: Optional[float] = None
    diastolic_bp: Optional[float] = None

    spo2: Optional[float] = None

    symptoms: Dict[str, bool]

    # timing
    symptom_onset_days: int  # 0=today, 1..7 days ago, 8=more than 7 days
    recent_travel: bool = False
    days_since_travel: Optional[int] = None
    contact_confirmed: bool = False
    days_since_contact: Optional[int] = None


class UserRegister(BaseModel):
    username: str
    password: str


class UserLogin(BaseModel):
    username: str
    password: str


# --- Simple user database (SQLite) ---
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        );
        """
    )
    conn.commit()
    conn.close()


def hash_password(password: str) -> str:
    # NOTE: for a real production system, use bcrypt/argon2.
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def register_user(username: str, password: str) -> bool:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO users (username, password_hash) VALUES (?, ?)",
            (username, hash_password(password)),
        )
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        # username already exists
        return False
    finally:
        conn.close()


def check_user(username: str, password: str) -> bool:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT password_hash FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    conn.close()
    if row is None:
        return False
    stored_hash = row[0]
    return stored_hash == hash_password(password)


# --- Load model and preprocessing on startup ---
print("Initializing system (DB + model + training data)...")
init_db()

try:
    nn_model = load_model(MODEL_PATH)
    print("Model loaded successfully.")
except Exception as e:
    print(f"FATAL ERROR: Could not load model: {e}")
    nn_model = None

try:
    df_train = pd.read_csv(TRAIN_PATH)
    # Drop entirely empty columns (like unnamed index columns)
    df_train = df_train.dropna(axis=1, how="all")
except Exception as e:
    print(f"FATAL ERROR: Could not load training data: {e}")
    df_train = None

if df_train is not None:
    # Separate features and labels
    feature_cols = [

        c
        for c in df_train.columns
        if c != "prognosis" and not c.lower().startswith("unnamed")
    ]
    X = df_train[feature_cols]
    y = df_train["prognosis"]

    # Encode labels
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)

    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X.values)  # noqa: F841  (just to fit scaler)

    print(f"Loaded training data with {X.shape[0]} samples and {X.shape[1]} features.")
else:
    feature_cols = []
    label_encoder = None
    scaler = None


def predict_disease(symptoms: List[str]) -> str:
    """
    Convert selected symptoms to a feature vector, run the NN model,
    and decode the predicted disease label.
    """
    # if nn_model is None or df_train is None or scaler is None or label_encoder is None:
    #     raise RuntimeError(
    #         "Model or preprocessing objects are not loaded properly on the server."
    #     )

    # Build binary vector for symptoms
    x_vec = np.zeros(len(feature_cols), dtype=float)

    # Map symptoms to columns if they exist
    # (frontend values should match training_data.csv column names)
    for symptom in symptoms:
        if symptom in feature_cols:
            idx = feature_cols.index(symptom)
            x_vec[idx] = 1.0

    x_vec = x_vec.reshape(1, -1)
    x_scaled = scaler.transform(x_vec)

    # Predict probabilities and choose highest
    prediction = nn_model.predict(x_scaled)
    predicted_index = int(np.argmax(prediction, axis=1)[0])
    predicted_label = label_encoder.inverse_transform([predicted_index])[0]

    return predicted_label



# --- Load / create COVID v2 model (synthetic baseline) ---
covid_model = None
covid_feature_names = None
try:
    covid_model, covid_feature_names = load_or_create(COVID_MODEL_PATH)
    print("COVID model ready.")
except Exception as e:
    print(f"WARNING: Could not initialize COVID model: {e}")
    covid_model = None
    covid_feature_names = None

@app.get("/")
def root():
    return {"message": "Disease Prediction API is running."}


# --- Auth endpoints ---

@app.post("/register")
def register_endpoint(data: UserRegister):
    username = data.username.strip()
    password = data.password.strip()

    if not username or not password:
        return {"success": False, "error": "Username and password are required."}

    ok = register_user(username, password)
    if not ok:
        return {"success": False, "error": "Username already exists."}

    return {"success": True, "message": "User registered successfully."}


@app.post("/login")
def login_endpoint(data: UserLogin):
    username = data.username.strip()
    password = data.password.strip()

    if not username or not password:
        return {"success": False, "error": "Username and password are required."}

    if check_user(username, password):
        return {"success": True, "message": "Login successful."}

    return {"success": False, "error": "Invalid username or password."}


# --- Prediction endpoint ---

@app.post("/predict")
def predict_endpoint(data: SymptomsInput):
    if not data.symptoms:
        return {"success": False, "error": "No symptoms provided."}

    try:
        result = predict_disease(data.symptoms)
        return {
            "success": True,
            "predicted_disease": result,
            "symptoms_received": data.symptoms,
        }
    except Exception as e:
        return {"success": False, "error": str(e)}




@app.post("/covid/assess")
def covid_assess_endpoint(data: CovidAssessInput):
    if covid_model is None:
        return {"success": False, "error": "COVID model is not initialized on the server."}

    try:
        # Base probability from model
        base_p = covid_predict_proba(
            covid_model,
            age=int(data.age),
            gender=str(data.gender),
            temperature_c=data.temperature_c if data.has_high_temp else None,
            systolic_bp=data.systolic_bp if data.has_high_bp else None,
            diastolic_bp=data.diastolic_bp if data.has_high_bp else None,
            spo2=data.spo2,
            symptoms=data.symptoms or {},
        )

        # Timing adjustment (incubation-aware)
        onset = int(data.symptom_onset_days)
        contact = data.contact_confirmed
        contact_days = int(data.days_since_contact) if data.days_since_contact is not None else None

        # If symptoms started today but contact was 1 day ago, reduce causality confidence slightly.
        timing_factor = 1.0
        if contact and contact_days is not None:
            # typical incubation is a few days; same/next-day symptoms are less likely to be caused by that contact
            if onset <= 1 and contact_days <= 1:
                timing_factor *= 0.85
            # contact after symptoms started -> do not boost current infection
            if contact_days < onset:
                timing_factor *= 0.95

        # travel timing: mainly affects future risk, minor current impact
        p_current = max(0.0, min(1.0, base_p * timing_factor))

        # Leveling thresholds
        def level(p: float) -> str:
            if p < 0.35:
                return "LOW"
            if p < 0.65:
                return "MEDIUM"
            return "HIGH"

        current_level = level(p_current)

        # Future exposure risk (only meaningful when current is LOW; frontend will decide visibility too)
        # See: travel/contact recentness
        p_future = 0.10
        if data.recent_travel and data.days_since_travel is not None:
            d = int(data.days_since_travel)
            if d <= 2:
                p_future += 0.35
            elif d <= 5:
                p_future += 0.22
            elif d <= 8:
                p_future += 0.12

        if data.contact_confirmed and data.days_since_contact is not None:
            d = int(data.days_since_contact)
            if d <= 2:
                p_future += 0.45
            elif d <= 5:
                p_future += 0.28
            elif d <= 8:
                p_future += 0.15

        # Cap and level
        p_future = max(0.0, min(1.0, p_future))
        future_level = level(p_future)

        show_future = current_level == "LOW"

        return {
            "success": True,
            "current": {"probability": p_current, "level": current_level},
            "future": {"probability": p_future, "level": future_level},
            "show_future": show_future,
        }

    except Exception as e:
        return {"success": False, "error": str(e)}

@app.get("/debug_model")
def debug_model():
    return {
        "nn_model_is_none": nn_model is None,
        "df_train_is_none": df_train is None,
        "scaler_is_none": scaler is None,
        "label_encoder_is_none": label_encoder is None,
        "feature_cols_len": len(feature_cols),
    }