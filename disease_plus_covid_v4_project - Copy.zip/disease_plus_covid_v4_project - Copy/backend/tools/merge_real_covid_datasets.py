"""Merge real COVID datasets (PhysioNet + Israel) into a single CSV for training.

Inputs (place in backend/data/raw/):
- physionet_subject_description.csv
- israel_corona_tested_individuals.xlsx

Output (created/overwritten):
- backend/data/covid_merged_real.csv

This is a *feature-level* merge (concatenation), not a patient-level join.
Missing fields are left as NaN.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Tuple

import numpy as np
import pandas as pd


BASE_DIR = Path(__file__).resolve().parents[1]
DATA_DIR = BASE_DIR / "data"
RAW_DIR = DATA_DIR / "raw"

PHYS_FILE = RAW_DIR / "physionet_subject_description.csv"
ISR_FILE = RAW_DIR / "israel_corona_tested_individuals.xlsx"
OUT_FILE = DATA_DIR / "covid_merged_real.csv"


def map_gender(val) -> str | float:
    if pd.isna(val):
        return np.nan
    s = str(val).strip()
    if s in ["זכר", "M", "Male", "male", "m"]:
        return "male"
    if s in ["נקבה", "F", "Female", "female", "f"]:
        return "female"
    return s.lower()


def map_israel_result(val) -> float:
    if pd.isna(val):
        return np.nan
    s = str(val).strip()
    # Hebrew: חיובי=positive, שלילי=negative
    if "חיובי" in s:
        return 1
    if "שלילי" in s:
        return 0
    sl = s.lower()
    if "positive" in sl:
        return 1
    if "negative" in sl:
        return 0
    return np.nan


def parse_bp(bp) -> Tuple[float, float]:
    if pd.isna(bp):
        return (np.nan, np.nan)
    s = str(bp).strip()
    m = re.search(r"(\\d{2,3})\\s*/\\s*(\\d{2,3})", s)
    if m:
        return (float(m.group(1)), float(m.group(2)))
    return (np.nan, np.nan)


def main() -> None:
    if not PHYS_FILE.exists():
        raise FileNotFoundError(f"Missing: {PHYS_FILE}")
    if not ISR_FILE.exists():
        raise FileNotFoundError(f"Missing: {ISR_FILE}")

    df_phys = pd.read_csv(PHYS_FILE)
    df_isr = pd.read_excel(ISR_FILE)

    # --- Israel (symptoms + label; no exact age/vitals) ---
    isr = pd.DataFrame(
        {
            "source": "israel",
            "age": np.nan,
            "age_60_plus": df_isr["age_60_and_above"].map(
                lambda x: 1
                if str(x).strip().lower() == "yes"
                else 0
                if str(x).strip().lower() == "no"
                else np.nan
            ),
            "gender": df_isr["gender"].map(map_gender),
            "cough": pd.to_numeric(df_isr["cough"], errors="coerce"),
            "fever": pd.to_numeric(df_isr["fever"], errors="coerce"),
            "sore_throat": pd.to_numeric(df_isr["sore_throat"], errors="coerce"),
            "shortness_of_breath": pd.to_numeric(df_isr["shortness_of_breath"], errors="coerce"),
            "headache": pd.to_numeric(df_isr["head_ache"], errors="coerce"),
            "temperature_c": np.nan,
            "spo2": np.nan,
            "bp_systolic": np.nan,
            "bp_diastolic": np.nan,
            "recent_travel": df_isr["test_indication"].map(
                lambda x: 1 if str(x).strip().lower() == "abroad" else 0
            ),
            "contact_confirmed": df_isr["test_indication"].map(
                lambda x: 1 if "contact" in str(x).lower() else 0
            ),
            "label": df_isr["corona_result"].map(map_israel_result),
        }
    )

    # --- PhysioNet (vitals + label; some symptoms may exist) ---
    bp_parsed = df_phys["Blood Pressure"].apply(parse_bp)
    exposure_cols = ["Home Exposure", "Hospital Exposure", "Work Exposure", "Other Exposure"]
    expos = df_phys[exposure_cols].apply(pd.to_numeric, errors="coerce")
    contact = expos.max(axis=1)

    phys = pd.DataFrame(
        {
            "source": "physionet",
            "age": pd.to_numeric(df_phys["AGE"], errors="coerce"),
            "age_60_plus": pd.to_numeric(df_phys["AGE"], errors="coerce").apply(
                lambda x: 1 if pd.notna(x) and x >= 60 else 0 if pd.notna(x) else np.nan
            ),
            "gender": df_phys["SEX"].map(map_gender),
            "cough": pd.to_numeric(df_phys.get("Cough", np.nan), errors="coerce"),
            "fever": pd.to_numeric(df_phys.get("Fever", np.nan), errors="coerce"),
            "sore_throat": pd.to_numeric(df_phys.get("Sore Throat", np.nan), errors="coerce"),
            "shortness_of_breath": pd.to_numeric(df_phys.get("Dyspnea", np.nan), errors="coerce")
            if "Dyspnea" in df_phys.columns
            else np.nan,
            "headache": pd.to_numeric(df_phys.get("Headache", np.nan), errors="coerce")
            if "Headache" in df_phys.columns
            else np.nan,
            "temperature_c": pd.to_numeric(df_phys.get("Body Temperature (°C)", np.nan), errors="coerce"),
            "spo2": pd.to_numeric(df_phys.get("SpO2", np.nan), errors="coerce"),
            "bp_systolic": [x[0] for x in bp_parsed],
            "bp_diastolic": [x[1] for x in bp_parsed],
            "recent_travel": np.nan,
            "contact_confirmed": contact,
            "label": df_phys["PCR Result"].map(
                lambda x: 1
                if str(x).strip().lower() == "positive"
                else 0
                if str(x).strip().lower() == "negative"
                else np.nan
            ),
        }
    )

    merged = pd.concat([phys, isr], ignore_index=True)
    merged = merged.dropna(subset=["label"]).copy()
    merged["label"] = merged["label"].astype(int)

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    merged.to_csv(OUT_FILE, index=False)
    print(f\"Saved: {OUT_FILE}  rows={len(merged)}  cols={len(merged.columns)}\")


if __name__ == \"__main__\":
    main()
