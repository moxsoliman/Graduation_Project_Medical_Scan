"""Train the COVID v2 model on backend/data/covid_merged_real.csv

Writes the trained model to:
- backend/models/covid_v2.joblib

The API automatically loads it on next run.
"""

from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
import joblib  # type: ignore

from backend.covid_model import FEATURE_NAMES, SYMPTOM_KEYS


BASE_DIR = Path(__file__).resolve().parents[1]
DATA_FILE = BASE_DIR / "data" / "covid_merged_real.csv"
MODEL_FILE = BASE_DIR / "models" / "covid_v2.joblib"


def main() -> None:
    if not DATA_FILE.exists():
        raise FileNotFoundError(
            f"Missing: {DATA_FILE}. Run tools/merge_real_covid_datasets.py first."
        )

    df = pd.read_csv(DATA_FILE)

    age = pd.to_numeric(df.get("age", np.nan), errors="coerce")
    age60 = pd.to_numeric(df.get("age_60_plus", np.nan), errors="coerce")

    # If age is missing, impute using age_60_plus
    age = age.where(
        age.notna(),
        np.where(age60 == 1, 65, np.where(age60 == 0, 30, 35)),
    ).astype(float)

    gender = df.get("gender", "").astype(str).str.lower()
    is_male = np.where(gender.eq("male"), 1.0, 0.0)

    temp = pd.to_numeric(df.get("temperature_c", np.nan), errors="coerce").fillna(36.8)
    sys = pd.to_numeric(df.get("bp_systolic", np.nan), errors="coerce").fillna(120.0)
    dia = pd.to_numeric(df.get("bp_diastolic", np.nan), errors="coerce").fillna(80.0)
    spo2 = pd.to_numeric(df.get("spo2", np.nan), errors="coerce").fillna(97.0)

    cough = pd.to_numeric(df.get("cough", 0), errors="coerce").fillna(0).clip(0, 1)
    fever = pd.to_numeric(df.get("fever", 0), errors="coerce").fillna(0).clip(0, 1)
    sore = pd.to_numeric(df.get("sore_throat", 0), errors="coerce").fillna(0).clip(0, 1)
    sob = pd.to_numeric(df.get("shortness_of_breath", 0), errors="coerce").fillna(0).clip(0, 1)
    head = pd.to_numeric(df.get("headache", 0), errors="coerce").fillna(0).clip(0, 1)

    sym_cols = {k: np.zeros(len(df), dtype=float) for k in SYMPTOM_KEYS}
    # Map available symptoms
    if "dry_cough" in sym_cols:
        sym_cols["dry_cough"] = cough.to_numpy(dtype=float)
    if "fever" in sym_cols:
        sym_cols["fever"] = fever.to_numpy(dtype=float)
    if "sore_throat" in sym_cols:
        sym_cols["sore_throat"] = sore.to_numpy(dtype=float)
    if "shortness_of_breath" in sym_cols:
        sym_cols["shortness_of_breath"] = sob.to_numpy(dtype=float)
    if "headache" in sym_cols:
        sym_cols["headache"] = head.to_numpy(dtype=float)

    X = np.column_stack(
        [
            age.to_numpy(dtype=float),
            is_male.astype(float),
            temp.to_numpy(dtype=float),
            sys.to_numpy(dtype=float),
            dia.to_numpy(dtype=float),
            spo2.to_numpy(dtype=float),
        ]
        + [sym_cols[k] for k in SYMPTOM_KEYS]
    )

    y = pd.to_numeric(df["label"], errors="coerce").fillna(0).astype(int).to_numpy()

    base = LogisticRegression(max_iter=300)
    clf = CalibratedClassifierCV(base, method="sigmoid", cv=3)
    clf.fit(X, y)

    MODEL_FILE.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": clf, "feature_names": FEATURE_NAMES}, MODEL_FILE)
    print(f"Saved trained model -> {MODEL_FILE}")


if __name__ == "__main__":
    main()
