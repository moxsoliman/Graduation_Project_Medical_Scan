import os
from typing import Dict, Optional, Tuple

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
import joblib  # type: ignore


# ----------------------------
# Model / feature definition
# ----------------------------
SYMPTOM_KEYS = [
    "fever",
    "dry_cough",
    "shortness_of_breath",
    "chest_tightness",
    "fatigue",
    "sore_throat",
    "runny_stuffy_nose",
    "sneezing",
    "hoarse_voice",
    "headache",
    "loss_smell",
    "loss_taste",
    "dizziness",
    "body_aches",
    "joint_pain",
    "nausea",
    "vomiting",
    "diarrhea",
    "stomach_pain",
    "chills",
]

FEATURE_NAMES = [
    "age",
    "is_male",
    "temperature_c",
    "systolic_bp",
    "diastolic_bp",
    "spo2",
] + [f"sym_{k}" for k in SYMPTOM_KEYS]


def _sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def _build_feature_vector(
    age: int,
    gender: str,
    temperature_c: Optional[float],
    systolic_bp: Optional[float],
    diastolic_bp: Optional[float],
    spo2: Optional[float],
    symptoms: Dict[str, bool],
) -> np.ndarray:
    is_male = 1.0 if gender.lower() == "male" else 0.0

    # Missing vitals -> neutral values with masking via simple defaults
    temp = float(temperature_c) if temperature_c is not None else 36.8
    sys = float(systolic_bp) if systolic_bp is not None else 120.0
    dia = float(diastolic_bp) if diastolic_bp is not None else 80.0
    ox = float(spo2) if spo2 is not None else 97.0

    x = [float(age), is_male, temp, sys, dia, ox]
    for k in SYMPTOM_KEYS:
        x.append(1.0 if symptoms.get(k, False) else 0.0)
    return np.array(x, dtype=float).reshape(1, -1)


# ----------------------------
# Synthetic training (default)
# ----------------------------
def _generate_synthetic(n: int = 60000, seed: int = 42) -> Tuple[np.ndarray, np.ndarray]:
    """Generate a synthetic dataset with plausible relationships.
    NOTE: This is a baseline model to make the project runnable out-of-the-box.
    You can replace it by training on real datasets later (same features).
    """
    rng = np.random.default_rng(seed)

    age = rng.integers(5, 90, size=n)
    is_male = rng.integers(0, 2, size=n)

    # Vitals (with noise)
    temperature = rng.normal(36.8, 0.5, size=n)
    systolic = rng.normal(122, 15, size=n)
    diastolic = rng.normal(80, 10, size=n)
    spo2 = rng.normal(97.0, 1.5, size=n)

    # Symptoms
    sym = rng.integers(0, 2, size=(n, len(SYMPTOM_KEYS))).astype(float)
    # Make core symptoms slightly more likely overall
    core_idx = [0, 1, 2, 4, 5, 9, 10, 11, 19]  # fever,cough,sob,fatigue,sore throat,headache,loss smell,taste,chills
    for i in core_idx:
        p = rng.uniform(0.15, 0.35)
        sym[:, i] = (rng.random(n) < p).astype(float)

    # Create latent risk score
    score = (
        0.015 * (age - 30)
        + 0.35 * sym[:, 0]  # fever
        + 0.25 * sym[:, 1]  # cough
        + 0.35 * sym[:, 2]  # SOB
        + 0.18 * sym[:, 4]  # fatigue
        + 0.12 * sym[:, 5]  # sore throat
        + 0.10 * sym[:, 9]  # headache
        + 0.25 * sym[:, 10] # loss smell
        + 0.25 * sym[:, 11] # loss taste
        + 0.15 * sym[:, 19] # chills
    )

    # Vitals influence (mild)
    score += 0.55 * np.clip((temperature - 37.5) / 1.2, 0, 2)
    score += 0.45 * np.clip((95.0 - spo2) / 4.0, 0, 2)

    # Convert to probability
    p = _sigmoid(score - 0.8)  # shift base rate lower
    y = (rng.random(n) < p).astype(int)

    # When positive, make some symptom/vital patterns more likely
    pos = y == 1
    temperature[pos] += rng.normal(0.6, 0.3, size=pos.sum())
    spo2[pos] -= rng.normal(0.7, 0.6, size=pos.sum())
    # Increase some symptoms for positives
    for i in core_idx:
        sym[pos, i] = (rng.random(pos.sum()) < 0.55).astype(float)

    X = np.column_stack([age, is_male, temperature, systolic, diastolic, spo2, sym])
    return X.astype(float), y


def train_and_save(model_path: str) -> None:
    X, y = _generate_synthetic()
    base = LogisticRegression(max_iter=200, n_jobs=None)
    # Calibrate for nicer probabilities
    clf = CalibratedClassifierCV(base, method="sigmoid", cv=3)
    clf.fit(X, y)
    joblib.dump({"model": clf, "feature_names": FEATURE_NAMES}, model_path)


def load_or_create(model_path: str):
    if not os.path.exists(model_path):
        os.makedirs(os.path.dirname(model_path), exist_ok=True)
        train_and_save(model_path)
    obj = joblib.load(model_path)
    return obj["model"], obj["feature_names"]


def predict_proba(
    model,
    age: int,
    gender: str,
    temperature_c: Optional[float],
    systolic_bp: Optional[float],
    diastolic_bp: Optional[float],
    spo2: Optional[float],
    symptoms: Dict[str, bool],
) -> float:
    x = _build_feature_vector(age, gender, temperature_c, systolic_bp, diastolic_bp, spo2, symptoms)
    proba = float(model.predict_proba(x)[0, 1])
    return max(0.0, min(1.0, proba))
