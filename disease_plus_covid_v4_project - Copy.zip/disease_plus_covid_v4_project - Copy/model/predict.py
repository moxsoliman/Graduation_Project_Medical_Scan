import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model # type: ignore
from sklearn.preprocessing import LabelEncoder, StandardScaler
import sys

# Load Model and Preprocessing Tools
try:
    nn_model = load_model('disease_prediction_model.keras')
except Exception as e:
    print(f"FATAL ERROR: Could not load the model file. Details: {e}")
    sys.exit()

try:
    df_train = pd.read_csv("training_data.csv")
    df_train = df_train.dropna(axis=1, how='all')
    
    y_train = df_train["prognosis"]
    label_encoder = LabelEncoder()
    label_encoder.fit(y_train)
    
    X_train = df_train.drop(columns=['prognosis'])
    
    scaler = StandardScaler()
    scaler.fit(X_train)
    
except Exception as e:
    print(f"FATAL ERROR: Data Preprocessing Failed. Details: {e}")
    sys.exit()


def predict_new_case(symptoms):
    
    symptom_data = X_train.iloc[0].copy() * 0 
    
    for symptom in symptoms:
        if symptom in symptom_data.index:
            symptom_data[symptom] = 1
        else:
            print(f"Warning: Symptom '{symptom}' is unknown and ignored.")
            
    input_data = symptom_data.values.reshape(1, -1)
    
    input_scaled = scaler.transform(input_data)
    
    prediction = nn_model.predict(input_scaled)
    
    predicted_index = np.argmax(prediction, axis=1)[0]
    
    predicted_disease = label_encoder.inverse_transform([predicted_index])[0]
    
    return predicted_disease

# Usage Example
new_patient_symptoms = ['itching', 'skin_rash', 'fatigue', 'high_fever']

result = predict_new_case(new_patient_symptoms)

print(f"Predicted Disease: **{result}**")