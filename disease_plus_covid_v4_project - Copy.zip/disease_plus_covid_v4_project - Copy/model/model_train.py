import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from tensorflow.keras.models import Sequential # type: ignore
from tensorflow.keras.layers import Dense, Dropout # type: ignore
from tensorflow.keras.utils import to_categorical # type: ignore
import joblib

# Load dataset
df = pd.read_csv("training_data.csv")

df = df.dropna(axis=1, how='all')
print(df.head()) 

print("✅ Dataset loaded successfully!")
print(df.head())

# Split features and target
X = df.drop(columns=["prognosis"])
y = df["prognosis"]

# Encode the target
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)
y_categorical = to_categorical(y_encoded)

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y_categorical, test_size=0.2, random_state=42, stratify=y_categorical
)


nn_model = Sequential([
    Dense(128, activation='relu', input_shape=(X_train.shape[1],)),
    Dropout(0.4),
    Dense(64, activation='relu'),
    Dense(y_categorical.shape[1], activation='softmax')
])

nn_model.compile(
    optimizer='adam', 
    loss='categorical_crossentropy', 
    metrics=['accuracy']
)
history = nn_model.fit(
    X_train, 
    y_train, 
    epochs=50, 
    batch_size=32, 
    validation_data=(X_test, y_test),
    verbose=0
)

loss, accuracy = nn_model.evaluate(X_test, y_test, verbose=0)

print(f"Model Test Accuracy: {accuracy:.4f}")

print("✅ Data preprocessing complete!")
print("Training samples:", X_train.shape)
print("Testing samples:", X_test.shape)
nn_model.save("disease_prediction_model.keras")