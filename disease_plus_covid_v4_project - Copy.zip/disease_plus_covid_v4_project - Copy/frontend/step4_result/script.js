// Load prediction result from localStorage and display it
document.addEventListener("DOMContentLoaded", function() {
  const resultElement = document.getElementById("resultText");
  const storedResult = localStorage.getItem("predictionResult");

  if (storedResult && resultElement) {
    resultElement.textContent = storedResult;
  }
});

document.getElementById("tryAgainBtn").addEventListener("click", function() {
  // Clear old data and restart the flow
  localStorage.removeItem("selectedSymptoms");
  localStorage.removeItem("predictionResult");
  window.location.href = "../step1_start/index.html";
});