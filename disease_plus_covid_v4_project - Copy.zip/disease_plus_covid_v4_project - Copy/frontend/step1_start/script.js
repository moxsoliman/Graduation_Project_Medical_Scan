document.getElementById("startDiseaseBtn").addEventListener("click", () => {
  window.location.href = "../step2_input/index.html";
});

document.getElementById("startCovidBtn").addEventListener("click", () => {
  window.location.href = "../covid_check_input/index.html";
});
