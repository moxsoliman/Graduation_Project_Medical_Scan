const API_BASE = "http://127.0.0.1:8000";

let mode = "register"; // 'register' for new user, 'login' for existing user

const newUserBtn = document.getElementById("newUserBtn");
const existingUserBtn = document.getElementById("existingUserBtn");
const formTitle = document.getElementById("formTitle");
const formSubtitle = document.getElementById("formSubtitle");
const loginForm = document.getElementById("loginForm");
const loginBtn = document.getElementById("loginBtn");
const usernameError = document.getElementById("usernameError");
const passwordError = document.getElementById("passwordError");
const formError = document.getElementById("formError");
const btnWarn = document.getElementById("btnWarn");

function clearErrors(){
  if (usernameError){ usernameError.textContent = ""; usernameError.style.display = "none"; }
  if (passwordError){ passwordError.textContent = ""; passwordError.style.display = "none"; }
  if (formError){ formError.textContent = ""; formError.style.display = "none"; }
  if (btnWarn){ btnWarn.classList.add("hidden"); }
}

function setFieldError(el, msg){
  if (!el) return;
  el.textContent = msg;
  el.style.display = "block";
  if (btnWarn){ btnWarn.classList.remove("hidden"); }
}

function setFormError(msg){
  if (!formError) return;
  formError.textContent = msg;
  formError.style.display = "block";
  if (btnWarn){ btnWarn.classList.remove("hidden"); }
}

// Switch to "New User" mode
newUserBtn.addEventListener("click", function () {
  mode = "register";
  newUserBtn.classList.add("active");
  existingUserBtn.classList.remove("active");
  formTitle.textContent = "Create a New Account";
  formSubtitle.textContent = "Register as a new user to start using the system.";
  loginBtn.textContent = "Create Account & Continue";
});

// Switch to "Existing User" mode
existingUserBtn.addEventListener("click", function () {
  mode = "login";
  existingUserBtn.classList.add("active");
  newUserBtn.classList.remove("active");
  formTitle.textContent = "Welcome Back";
  formSubtitle.textContent = "Log in with your existing account.";
  loginBtn.textContent = "Login & Continue";
});

// Handle form submit
loginForm.addEventListener("submit", function (event) {
  event.preventDefault();

  clearErrors();

  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();

  let hasErr = false;
  if (username === "") { setFieldError(usernameError, "Username is required."); hasErr = true; }
  if (password === "") { setFieldError(passwordError, "Password is required."); hasErr = true; }
  if (hasErr) return;

  const endpoint = mode === "register" ? "/register" : "/login";

  fetch(API_BASE + endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ username, password }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        // Optionally store username for later use
        localStorage.setItem("currentUser", username);
        window.location.href = "../step1_start/index.html";
      } else {
        // show a small inline message (no browser alerts)
        setFormError(data.error || "Invalid username or password.");
      }
    })
    .catch((error) => {
      console.error("Error:", error);
      setFormError("Could not contact the server. Make sure the backend is running.");
    });
});
