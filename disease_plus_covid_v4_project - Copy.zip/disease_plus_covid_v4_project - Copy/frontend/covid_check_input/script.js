const symptomDefs = [
  { key: "fever", label: "Fever" },
  { key: "dry_cough", label: "Dry cough" },
  { key: "shortness_of_breath", label: "Shortness of breath" },
  { key: "chest_tightness", label: "Chest pain or tightness" },
  { key: "fatigue", label: "Fatigue (unusual tiredness)" },
  { key: "sore_throat", label: "Sore throat" },
  { key: "runny_stuffy_nose", label: "Runny or stuffy nose" },
  { key: "sneezing", label: "Sneezing" },
  { key: "hoarse_voice", label: "Hoarse voice" },
  { key: "headache", label: "Headache" },
  { key: "loss_smell", label: "Loss of smell" },
  { key: "loss_taste", label: "Loss of taste" },
  { key: "dizziness", label: "Dizziness" },
  { key: "body_aches", label: "Muscle or body aches" },
  { key: "joint_pain", label: "Joint pain" },
  { key: "nausea", label: "Nausea" },
  { key: "vomiting", label: "Vomiting" },
  { key: "diarrhea", label: "Diarrhea" },
  { key: "stomach_pain", label: "Stomach pain" },
  { key: "chills", label: "Chills or shivering" },
];

const symptomGrid = document.getElementById("symptomGrid");
const ageError = document.getElementById("ageError");
const genderError = document.getElementById("genderError");
const formError = document.getElementById("formError");
const submitWarn = document.getElementById("submitWarn");

function clearErrors(){
  if (ageError){ ageError.textContent = ""; ageError.style.display = "none"; }
  if (genderError){ genderError.textContent = ""; genderError.style.display = "none"; }
  if (formError){ formError.textContent = ""; formError.style.display = "none"; }
  if (submitWarn){ submitWarn.classList.add("hidden"); }
}

function setFieldError(el, msg){
  if (!el) return;
  el.textContent = msg;
  el.style.display = "block";
  if (submitWarn){ submitWarn.classList.remove("hidden"); }
}

function setFormError(msg){
  if (!formError) return;
  formError.textContent = msg;
  formError.style.display = "block";
  if (submitWarn){ submitWarn.classList.remove("hidden"); }
}

function addDayOptions(selectEl, includeToday=false){
  selectEl.innerHTML = "";
  if (includeToday){
    const opt = document.createElement("option");
    opt.value = "0";
    opt.textContent = "today";
    selectEl.appendChild(opt);
  }
  for (let d=1; d<=7; d++){
    const opt = document.createElement("option");
    opt.value = String(d);
    opt.textContent = `${d} day${d===1? "":"s"} ago`;
    selectEl.appendChild(opt);
  }
  const opt8 = document.createElement("option");
  opt8.value = "8";
  opt8.textContent = "more than 7 days";
  selectEl.appendChild(opt8);
}

function initSymptoms(){
  for (const s of symptomDefs){
    const label = document.createElement("label");
    label.className = "symptomItem";
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.value = s.key;
    const text = document.createElement("span");
    text.textContent = s.label;
    label.appendChild(cb);
    label.appendChild(text);
    symptomGrid.appendChild(label);
  }
}

function initTiming(){
  addDayOptions(document.getElementById("symptomOnset"), true);
  addDayOptions(document.getElementById("travelWhen"), false);
  addDayOptions(document.getElementById("contactWhen"), false);
  // force onset selection (required) -> we keep a default "today"
}

function bindToggles(){
  const hasHighTemp = document.getElementById("hasHighTemp");
  const temp = document.getElementById("temperature");
  hasHighTemp.addEventListener("change", () => {
    temp.disabled = !hasHighTemp.checked;
    if (!hasHighTemp.checked) temp.value = "";
  });

  const hasHighBP = document.getElementById("hasHighBP");
  const sys = document.getElementById("systolic");
  const dia = document.getElementById("diastolic");
  hasHighBP.addEventListener("change", () => {
    const enabled = hasHighBP.checked;
    sys.disabled = !enabled;
    dia.disabled = !enabled;
    if (!enabled){ sys.value=""; dia.value=""; }
  });

  const travel = document.getElementById("recentTravel");
  const travelWrap = document.getElementById("travelWhenWrap");
  travel.addEventListener("change", () => {
    travelWrap.classList.toggle("hidden", travel.value !== "yes");
  });

  const contact = document.getElementById("contactConfirmed");
  const contactWrap = document.getElementById("contactWhenWrap");
  contact.addEventListener("change", () => {
    contactWrap.classList.toggle("hidden", contact.value !== "yes");
  });
}

function buildPayload(){
  clearErrors();
  const age = document.getElementById("age").value;
  const gender = document.getElementById("gender").value;

  const hasHighTemp = document.getElementById("hasHighTemp").checked;
  const temperature = document.getElementById("temperature").value;

  const hasHighBP = document.getElementById("hasHighBP").checked;
  const systolic = document.getElementById("systolic").value;
  const diastolic = document.getElementById("diastolic").value;

  const spo2Val = document.getElementById("spo2").value;

  const symptomOnsetDays = document.getElementById("symptomOnset").value; // required (default today)
  const recentTravel = document.getElementById("recentTravel").value;
  const daysSinceTravel = document.getElementById("travelWhen").value;

  const contactConfirmed = document.getElementById("contactConfirmed").value;
  const daysSinceContact = document.getElementById("contactWhen").value;

  const symptoms = {};
  for (const s of symptomDefs){
    const checked = symptomGrid.querySelector(`input[value="${s.key}"]`).checked;
    symptoms[s.key] = checked;
  }

  // Basic required checks
  let hasErr = false;
  if (!age){ setFieldError(ageError, "Age is required."); hasErr = true; }
  if (!gender){ setFieldError(genderError, "Gender is required."); hasErr = true; }
  if (hasErr){
    return { error: true };
  }

  return {
    age: Number(age),
    gender: gender,
    has_high_temp: hasHighTemp,
    temperature_c: hasHighTemp && temperature !== "" ? Number(temperature) : null,

    has_high_bp: hasHighBP,
    systolic_bp: hasHighBP && systolic !== "" ? Number(systolic) : null,
    diastolic_bp: hasHighBP && diastolic !== "" ? Number(diastolic) : null,

    spo2: spo2Val === "" ? null : Number(spo2Val),

    symptoms: symptoms,

    symptom_onset_days: Number(symptomOnsetDays),

    recent_travel: recentTravel === "yes",
    days_since_travel: recentTravel === "yes" ? Number(daysSinceTravel) : null,

    contact_confirmed: contactConfirmed === "yes",
    days_since_contact: contactConfirmed === "yes" ? Number(daysSinceContact) : null
  };
}

async function submit(){
  const payload = buildPayload();
  if (payload.error){
    return;
  }

  // Save payload to display later if needed
  localStorage.setItem("covidInput", JSON.stringify(payload));

  try{
    const res = await fetch("http://127.0.0.1:8000/covid/assess", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!data.success){
      setFormError(data.error || "Failed to assess.");
      return;
    }
    localStorage.setItem("covidResult", JSON.stringify(data));
    window.location.href = "../covid_check_result/index.html";
  }catch(e){
    setFormError("Failed to connect to the backend. Make sure the server is running.");
  }
}

document.getElementById("submitBtn").addEventListener("click", submit);
document.getElementById("backBtn").addEventListener("click", () => {
  window.location.href = "../step1_start/index.html";
});

initSymptoms();
initTiming();
bindToggles();
