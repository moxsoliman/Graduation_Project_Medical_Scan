// When the processing page loads, send the selected symptoms to the backend API
document.addEventListener("DOMContentLoaded", function() {
  const stored = localStorage.getItem("selectedSymptoms");
  if (!stored) {
    // No symptoms stored, go back to selection page
    window.location.href = "../step2_input/index.html";
    return;
  }

  const selectedSymptoms = JSON.parse(stored);

  // Call the backend API
  fetch("http://127.0.0.1:8000/predict", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ symptoms: selectedSymptoms })
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        localStorage.setItem("predictionResult", data.predicted_disease);
      } else {
        localStorage.setItem("predictionResult", "Error: " + (data.error || "Unknown error"));
      }
      window.location.href = "../step4_result/index.html";
    })
    .catch(error => {
      console.error("Error calling backend:", error);
      localStorage.setItem("predictionResult", "Error: Could not contact server.");
      window.location.href = "../step4_result/index.html";
    });
});