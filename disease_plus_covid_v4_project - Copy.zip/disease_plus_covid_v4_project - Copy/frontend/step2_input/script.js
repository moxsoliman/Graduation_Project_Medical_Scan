const symptomListEl = document.getElementById("symptomList");
const searchEl = document.getElementById("symptomSearch");
const countEl = document.getElementById("selectedCount");
const formErrorEl = document.getElementById("formError");

let catalog = [];

function updateCount() {
  const selected = symptomListEl.querySelectorAll('input[type="checkbox"]:checked').length;
  countEl.textContent = `${selected} selected`;
}

function renderList(filterText = "") {
  const q = filterText.trim().toLowerCase();
  symptomListEl.innerHTML = "";

  const items = q
    ? catalog.filter(item => item.label.toLowerCase().includes(q))
    : catalog;

  if (items.length === 0) {
    symptomListEl.innerHTML = `<div class="empty">No matches.</div>`;
    return;
  }

  // Create 3 fixed columns (for 300 items = 100 per column)
  const colsWrap = document.createElement("div");
  colsWrap.className = "symptomCols";

  const colEls = [0,1,2].map(() => {
    const col = document.createElement("div");
    col.className = "symptomCol";
    colsWrap.appendChild(col);
    return col;
  });

  const chunkSize = Math.ceil(items.length / 3);
  items.forEach((item, idx) => {
    const colIdx = Math.min(2, Math.floor(idx / chunkSize));
    const id = `sym_${item.label.replace(/\s+/g, "_").toLowerCase()}_${item.value}`;

    const wrap = document.createElement("label");
    wrap.className = "symptomItem";
    wrap.setAttribute("for", id);

    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.id = id;
    // IMPORTANT: send the model feature name (value), not the UI label
    cb.value = item.value;

    const text = document.createElement("span");
    text.textContent = item.label;

    cb.addEventListener("change", updateCount);

    wrap.appendChild(cb);
    wrap.appendChild(text);

    colEls[colIdx].appendChild(wrap);
  });

  symptomListEl.appendChild(colsWrap);
}


function showError(msg){
  if (!formErrorEl) return;
  formErrorEl.textContent = msg;
  formErrorEl.classList.remove("hidden");
}

function clearError(){
  if (!formErrorEl) return;
  formErrorEl.textContent = "";
  formErrorEl.classList.add("hidden");
}

async function init() {
  try {
    const res = await fetch("../assets/symptom_catalog.json");
    catalog = await res.json();
    renderList();
    updateCount();
  } catch (e) {
    symptomListEl.innerHTML = `<div class="empty">Failed to load symptom list.</div>`;
  }
}

searchEl.addEventListener("input", (e) => {
  renderList(e.target.value);
  updateCount();
  clearError();
});

document.getElementById("predictBtn").addEventListener("click", () => {
  const selectedSymptoms = Array.from(
    symptomListEl.querySelectorAll('input[type="checkbox"]:checked')
  ).map(cb => cb.value);

  // dedupe (aliases can map to the same value)
  const deduped = Array.from(new Set(selectedSymptoms));

  if (deduped.length === 0) {
    showError("Please select at least one symptom before proceeding.");
    return;
  }

  clearError();

  localStorage.setItem("selectedSymptoms", JSON.stringify(deduped));
  window.location.href = "../step3_processing/index.html";
});

document.getElementById("backBtn").addEventListener("click", () => {
  window.location.href = "../step1_start/index.html";
});

init();
