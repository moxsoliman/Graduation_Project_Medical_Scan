function colorStyle(level){
  // shared color system for BOTH cards
  if (level === "LOW"){
    return {
      bg: "rgba(46, 125, 50, 0.18)",
      border: "rgba(46, 125, 50, 0.45)",
      badge: "rgba(46, 125, 50, 0.22)"
    };
  }
  if (level === "MEDIUM"){
    return {
      bg: "rgba(251, 192, 45, 0.20)",
      border: "rgba(251, 192, 45, 0.50)",
      badge: "rgba(251, 192, 45, 0.26)"
    };
  }
  // HIGH
  return {
    bg: "rgba(211, 47, 47, 0.20)",
    border: "rgba(211, 47, 47, 0.50)",
    badge: "rgba(211, 47, 47, 0.24)"
  };
}

function pct(x){
  return Math.round(x * 100);
}

function currentCopy(level){
  if (level === "LOW"){
    return {
      title: "Low Risk",
      msg: "You are likely NOT infected with COVID-19."
    };
  }
  if (level === "MEDIUM"){
    return {
      title: "Medium Risk",
      msg: "You MIGHT be infected with COVID-19.",
      note: "To be sure, it’s recommended to take an accurate test and talk to a doctor."
    };
  }
  return {
    title: "High Risk",
    msg: "You are likely infected with COVID-19.",
    note: "Avoid going out or close contact with others, and contact a doctor as soon as possible."
  };
}

function futureCopy(level){
  if (level === "LOW"){
    return "Based on your recent activities, your risk of getting infected in the coming days is low.";
  }
  if (level === "MEDIUM"){
    return "You may have some risk of getting infected in the coming days based on recent exposure.";
  }
  return "Your recent contact or travel may increase the chance of infection in the coming days.";
}

function renderCard(el, title, badgeText, probability, message, note, level){
  const cs = colorStyle(level);
  el.style.background = cs.bg;
  el.style.borderColor = cs.border;

  el.innerHTML = `
    <div class="resultTitle">
      <div><strong>${title}</strong></div>
      <div class="badge" style="background:${cs.badge}">${badgeText}</div>
    </div>
    <div class="big">Estimated chance: ${pct(probability)}%</div>
    <p class="small">${message}</p>
    ${note ? `<p class="note">${note}</p>` : ``}
  `;
}

function init(){
  const dataRaw = localStorage.getItem("covidResult");
  if (!dataRaw){
    window.location.href = "../covid_check_input/index.html";
    return;
  }
  const data = JSON.parse(dataRaw);

  const current = data.current;
  const cCopy = currentCopy(current.level);

  const currentEl = document.getElementById("currentCard");
  renderCard(
    currentEl,
    "Current COVID-19 likelihood",
    cCopy.title,
    current.probability,
    cCopy.msg,
    cCopy.note || "",
    current.level
  );

  const futureWrap = document.getElementById("futureCardWrap");
  if (data.show_future && data.future){
    futureWrap.classList.remove("hidden");
    const futureEl = document.getElementById("futureCard");
    renderCard(
      futureEl,
      "Future exposure risk",
      data.future.level === "LOW" ? "Low" : (data.future.level === "MEDIUM" ? "Medium" : "High"),
      data.future.probability,
      futureCopy(data.future.level),
      "",
      data.future.level
    );
  }

  document.getElementById("againBtn").addEventListener("click", () => {
    window.location.href = "../covid_check_input/index.html";
  });
  document.getElementById("homeBtn").addEventListener("click", () => {
    window.location.href = "../step1_start/index.html";
  });
}

init();
